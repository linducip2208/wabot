-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.4.9 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table wabot.api_tokens
CREATE TABLE IF NOT EXISTS `api_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_tokens_token_unique` (`token`),
  KEY `api_tokens_user_id_foreign` (`user_id`),
  CONSTRAINT `api_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.api_tokens: ~0 rows (approximately)

-- Dumping structure for table wabot.cache
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.cache: ~0 rows (approximately)

-- Dumping structure for table wabot.cache_locks
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.cache_locks: ~0 rows (approximately)

-- Dumping structure for table wabot.contact_groups
CREATE TABLE IF NOT EXISTS `contact_groups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contact_groups_user_id_foreign` (`user_id`),
  CONSTRAINT `contact_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.contact_groups: ~0 rows (approximately)

-- Dumping structure for table wabot.contact_group_pivot
CREATE TABLE IF NOT EXISTS `contact_group_pivot` (
  `contact_id` bigint unsigned NOT NULL,
  `group_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`contact_id`,`group_id`),
  KEY `contact_group_pivot_group_id_foreign` (`group_id`),
  CONSTRAINT `contact_group_pivot_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `wa_contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contact_group_pivot_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `contact_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.contact_group_pivot: ~0 rows (approximately)

-- Dumping structure for table wabot.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.failed_jobs: ~0 rows (approximately)

-- Dumping structure for table wabot.jobs
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.jobs: ~0 rows (approximately)

-- Dumping structure for table wabot.job_batches
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.job_batches: ~0 rows (approximately)

-- Dumping structure for table wabot.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.migrations: ~18 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '0001_01_01_000000_create_users_table', 1),
	(2, '0001_01_01_000001_create_cache_table', 1),
	(3, '0001_01_01_000002_create_jobs_table', 1),
	(4, '2026_06_25_165133_create_wa_servers_table', 1),
	(5, '2026_06_25_165134_create_wa_sessions_table', 1),
	(6, '2026_06_25_165135_create_wa_autoreplies_table', 1),
	(7, '2026_06_25_165136_create_wa_contacts_table', 1),
	(8, '2026_06_25_165137_create_wa_campaigns_table', 1),
	(9, '2026_06_25_165138_create_wa_messages_table', 1),
	(10, '2026_06_25_170121_create_plans_table', 2),
	(11, '2026_06_25_170122_create_subscriptions_table', 2),
	(12, '2026_06_25_170337_create_personal_access_tokens_table', 2),
	(13, '2026_06_25_192243_add_display_phone_to_wa_contacts', 3),
	(14, '2026_06_25_194221_create_wa_recurrings_table', 4),
	(15, '2026_06_25_194935_add_delay_to_wa_campaigns', 5),
	(16, '2026_06_25_195457_create_wa_session_logs_table', 6),
	(17, '2026_06_25_201020_create_contact_groups_table', 7),
	(18, '2026_06_25_201021_create_api_tokens_table', 7);

-- Dumping structure for table wabot.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.password_reset_tokens: ~0 rows (approximately)

-- Dumping structure for table wabot.personal_access_tokens
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.personal_access_tokens: ~0 rows (approximately)

-- Dumping structure for table wabot.plans
CREATE TABLE IF NOT EXISTS `plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `billing_period` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `features` json DEFAULT NULL,
  `max_sessions` int NOT NULL DEFAULT '1',
  `max_contacts` int NOT NULL DEFAULT '100',
  `max_autoreplies` int NOT NULL DEFAULT '10',
  `max_campaign_recipients` int NOT NULL DEFAULT '50',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plans_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.plans: ~3 rows (approximately)
INSERT INTO `plans` (`id`, `name`, `slug`, `price`, `billing_period`, `features`, `max_sessions`, `max_contacts`, `max_autoreplies`, `max_campaign_recipients`, `is_active`, `sort_order`, `created_at`, `updated_at`) VALUES
	(1, 'Free', 'free', 0.00, 'monthly', '["Auto-Reply Keyword"]', 1, 100, 10, 50, 1, 1, '2026-06-25 10:04:30', '2026-06-25 10:04:30'),
	(2, 'Growth', 'growth', 150000.00, 'monthly', '["Auto-Reply Keyword", "Import CSV", "API Access", "Webhook"]', 3, 5000, 50, 1000, 1, 2, '2026-06-25 10:04:30', '2026-06-25 10:04:30'),
	(3, 'Enterprise', 'enterprise', 500000.00, 'monthly', '["Auto-Reply Keyword", "Import CSV", "API Access", "Webhook", "Whitelabel", "Reseller", "Priority Support"]', 10, 50000, 200, 10000, 1, 3, '2026-06-25 10:04:30', '2026-06-25 10:04:30');

-- Dumping structure for table wabot.sessions
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.sessions: ~33 rows (approximately)
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
	('46hQekbLbiDKows1ecQTY8aF8fX86XQsaEXIGIOB', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJ1dGpQS0k4dmpjZnpMdEdzbUtzdVpqR0pKdjQ2TUhBSEJ5dmQxQWtFIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442647),
	('4MXr2kfU6YUBAQIu9gNDRP7jimgjQDofplrDtXYq', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJ3czg1VmI2aUZXRXlTYzFmRnRyRWlKdFlNOTBzbUV5TXQ3WVpsY2hFIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782443230),
	('9AKFIwxJrko1DZMGcs8SnNZJzHn3G8WuXgygqzxm', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJ3bURVamltWjVyVjI4YWFtbjFEUmJudkxScWhtWlF1UERCQjlEeFZEIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442730),
	('ABmK5hksHrcNdB2YFZCNAryi37zAzLxasYtRTDRy', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJmaWcwaGRKWjFOUWh6RjdUb2V2dDh2emRzQWtZQjRVdGhBVERMQ3dMIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442074),
	('AIchDpINUF7XQ298jOmNzsWKeNx5LDtPv8EcRvpx', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJzdG9xZlZKWUZPRDBwNDd5bXNRbkxTekhYSEFWd2s4YnN2a1NlM25uIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442675),
	('b1G1LGTHRxNbyLUsPy6KlyZJUHdwKd8lmvmxzrep', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiIzNXhYWGNSZWFFTFI3N0QzQkRWenBWZU5UVDNlSWtacUZVU3NFMUJzIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442664),
	('BHcY5RNYXk7jcISYX48MtAe5ONssTtv9ClqxBKYT', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', 'eyJfdG9rZW4iOiJXa2R5YkgwWFBNMXpZM2RwcjZVR1lxd1VsZkt4NUE0dlppUHJvSTZkIiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL3dhYm90LnRlc3RcL2FwaVwvY2hhdFwvY29udGFjdHMiLCJyb3V0ZSI6ImNoYXQuY29udGFjdHMifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MX0=', 1782443742),
	('dtZS64DD5u9aMIwqw5AxsB6l90IGXv3NnwJE8vap', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJvRXVDdDRJaEUwbm1iVVVkOHhNN1haNEoxaFZBS1NQZGVJY3c1VVNCIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441657),
	('Hv753w7YepahTKQI98Q3dPFm9HfMODQ2EEaSnUcd', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJPZDNhNjR0dmh6cGo3ZDh5b3Q5dHA5TWNodjB2c21Pc0pGOWJ6UlN3IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441897),
	('i7yzGGoeuJ4RNB5W4gpuGCHBrAtHgqTudH3JptXJ', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJVWFhHWUZsMkRpTWFudklqVXA3VmRmUmo0NXJtb2FRZHp4NWNWNU5KIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442712),
	('jio9nUY0FTiutTWfKslkOQ5yLtklywoLPae78Paz', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJ5anRjRWlZMmdLaDBtZ25BQXIxWTEwcEw2TU10bHlOOUhyS2dxcEJ0IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441789),
	('Kiy3shlTAmXCeXDr9WgyNSG3YEk8PJU1FZH69cnP', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJhUVgxcmtsZ3dQNlh1UWRneDZ6WHVsdVdwM3JHTzN1Z3VNNVpMZjZiIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782443100),
	('m8pzqixGZxHo1AXUkgPwI5igiAirEauSJ1Mt5xQ4', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJiS3BPOHUxb3haZlZ0Z3hyd21kUVdsRzhjMzJ6bFZ5ZFV3VVBjTDJJIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441074),
	('mkNjAhnPg4hEAlDy4VqPlHn5MgHapkZ38PEksU6X', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiIyUHAyYWNxcGVlVGJzS3RKUE1MQmxXVHoxcVdHb25lM3dWcU1rOFY1IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441722),
	('nDTRpeY5tPgNERvlTrudWKZSBab82JfQEEGv8vTa', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJSWFdnbldPcGc1bld3QkdGZkFKSlBuMXBMNzRHMDZTOG02UjdKN1ZxIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441108),
	('nWtiAjH17vZK3FIiSnpmyUNE638PR5O9rFYvaG1S', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJhSGJqZkxFaTBwV2YzZ2VyN3hvZTh4SHgyRnUzemFvdlQyb094RW9CIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442723),
	('pFysqaiTy8dwP89bEpD7RY5g7nBhBO3qrvmKXC6E', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJ3dzFKVmpvT01GU0p0YjhramJDWXFhRHVFN3BHWnprWHFrNklIeUxIIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441072),
	('PniuuBj0XljTanYAoF9STcoNd1Q9hlSyaXjrsZqX', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJXQmVJRWdkWDNTaVMxTjJDWk93MmRPbjB2ZmszNjVUVmx2UURxbHRkIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441655),
	('qDdwpsg5IAD1eB2jS8mupe8J0JoWBuiXa1jx6Kza', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJnbGlnSTBpcEtFNEE2MlZXY3QyamI5VTFlVld4akFjVUNCSUxaWG1OIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442722),
	('Re9sE4l1D2GefwNq2Yah9OPhg4gIzavbqUi0i2cI', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJ3T2JSalB2bEtrUkd3Zm9PREFHcEc5TlBXSnFOaTVhckVCN1ZBMk5tIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782443233),
	('Rt4xGhW6VFU2CXGfgCxdwVUm5nETqeMQosB9bRVg', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJ6R1BiNXRwc1hNOTZONGFhamw2ZExnQll2ejZXWkJZT0FrTTlPMHFwIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442732),
	('si9qfqPQfTzaVrpiRclW9Cn6mOWtqLRuQuoS3fRC', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJiaUJKeEwzMGJ6UnVuZkJwOVFHTVZwZFR4akNXOWNhS0NydktUbWkwIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441290),
	('SiK5hAIrgtrw2CcpwXNe4MPzzhifVkjYDnPi45eo', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJjVGZsZXdFdzJhaFFydEdUdkJQaFNYM0lFTzYzR2VmYkwxanlPSHlKIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441071),
	('UG0lEBbEdCtzxEpNIu7uLjrsMLDnhcCkHtzTOnUc', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJoUmpVV0Z3UWlrdnJ0WVVXd25HTGFGSjlvbEdFZHNFbmVMcWQ4d05BIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442633),
	('vajFUqoWVW4gvGCjlO0aKTfdu9VnynhzweteIfFE', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiI2bFpFcW9BNlQ4RG5YM05HdTlsTTc4Y001OGtwRHNseWZKUmZCbTAyIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441901),
	('VHfMoOqvM09zffxIDQaCEhEKq7PJ2yQAzD98D2cJ', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJFcHFoeUxNTmdPWmtwTUlDVFh6dVp3WXpvQUE5UE9KRng3aTlvRWpPIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442623),
	('wcr2DyrcTUhTCvsrYxldPKzvPpLxr22jFM0SE4aP', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJjRDdUendKRDRaUXp4ZERxc3FDSW0zNk80eUtySEdSN0NZaTZaeGQxIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442620),
	('WKtHvB5nJe11S97tihUj7bg4GWPIJHq10OIRNXyC', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJtWXNyR3FIWXZ3MVI0cHdQWHduYU1vVkFvbWlHQ2R0MElRRmhqWWpwIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442338),
	('X13se3NyUJCANtl3bRY3quoXYPIRHE0lAuJUySzT', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJ4MTZYb1FxSUg4dnM1Ukp4NEsxdktuNVRtRk9IdXE3SVNubWZaUlNCIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442303),
	('XZH2WYHNhYNyTiGVeSjPLC2jy1RJwFpTF10B5KHP', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', 'eyJfdG9rZW4iOiI4UU9hSmtadXpRcTlxR1k2MXU1R2h5N2d6NVRWcGpZVmVCUjlCUzBZIiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL3dhYm90LnRlc3RcL2FkbWluXC91c2VycyIsInJvdXRlIjoiYWRtaW4udXNlcnMuaW5kZXgifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MX0=', 1782441845),
	('yfvF4LrP8yKU7pMcitISzzFO5ZQSnkf15SM1lAeb', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJ6MzhJUmRONUxtN2g5QnQzcmlMdFVIWjdSYmtLbUREaWRRbVFhVHBvIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782442657),
	('Z8wtXp9Ma0RQvCw1U2GSf7VbQaNCSz68oqAbGVJL', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJhVFlndjNDSklQTjh6Tm95Z0NzTkhzS0VBdDg3VmdmQWE0NFB0dmNpIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441555),
	('zzOSjuaxtiDTr9UflgpLT0yxVjSY978nH2M3imR4', NULL, '127.0.0.1', 'node', 'eyJfdG9rZW4iOiJObzVVdDBQcDJpQWF6bmcyMnBZVm9OU2pZTmJhVUxyTEdLQ3BHUk81IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1782441907);

-- Dumping structure for table wabot.subscriptions
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `canceled_at` timestamp NULL DEFAULT NULL,
  `payment_meta` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_user_id_foreign` (`user_id`),
  KEY `subscriptions_plan_id_foreign` (`plan_id`),
  CONSTRAINT `subscriptions_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.subscriptions: ~2 rows (approximately)
INSERT INTO `subscriptions` (`id`, `user_id`, `plan_id`, `status`, `starts_at`, `ends_at`, `canceled_at`, `payment_meta`, `created_at`, `updated_at`) VALUES
	(1, 1, 3, 'inactive', '2026-06-25 19:39:25', NULL, NULL, NULL, '2026-06-25 19:39:25', '2026-06-25 19:40:48'),
	(2, 1, 3, 'active', '2026-06-25 19:40:48', NULL, NULL, NULL, '2026-06-25 19:40:48', '2026-06-25 19:40:48');

-- Dumping structure for table wabot.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan_id` bigint unsigned DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_plan_id_foreign` (`plan_id`),
  CONSTRAINT `users_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.users: ~1 rows (approximately)
INSERT INTO `users` (`id`, `plan_id`, `trial_ends_at`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 3, NULL, 'Admin', 'admin@wabot.test', NULL, '$2y$12$SlaYYRPbIe5x.9m9Y5djaOSyuZQyNwsBPae2NtnYShCzFMhAS21iS', NULL, '2026-06-25 10:25:20', '2026-06-25 19:40:48');

-- Dumping structure for table wabot.wa_autoreplies
CREATE TABLE IF NOT EXISTS `wa_autoreplies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `session_id` bigint unsigned DEFAULT NULL,
  `keyword` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reply_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_type` enum('exact','contains','starts_with') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'contains',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wa_autoreplies_user_id_foreign` (`user_id`),
  KEY `wa_autoreplies_session_id_foreign` (`session_id`),
  CONSTRAINT `wa_autoreplies_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `wa_sessions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `wa_autoreplies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.wa_autoreplies: ~1 rows (approximately)
INSERT INTO `wa_autoreplies` (`id`, `user_id`, `session_id`, `keyword`, `reply_message`, `match_type`, `is_active`, `created_at`, `updated_at`) VALUES
	(2, 1, NULL, 'hi', 'silahkan mau tanya apa saja?', 'contains', 1, '2026-06-25 12:08:56', '2026-06-25 12:21:30');

-- Dumping structure for table wabot.wa_campaigns
CREATE TABLE IF NOT EXISTS `wa_campaigns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `session_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `delay_seconds` int NOT NULL DEFAULT '3',
  `media_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `recipient_ids` json NOT NULL,
  `status` enum('draft','sending','sent','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `total_recipients` int NOT NULL DEFAULT '0',
  `sent_count` int NOT NULL DEFAULT '0',
  `failed_count` int NOT NULL DEFAULT '0',
  `scheduled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wa_campaigns_user_id_foreign` (`user_id`),
  KEY `wa_campaigns_session_id_foreign` (`session_id`),
  CONSTRAINT `wa_campaigns_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `wa_sessions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `wa_campaigns_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.wa_campaigns: ~0 rows (approximately)

-- Dumping structure for table wabot.wa_contacts
CREATE TABLE IF NOT EXISTS `wa_contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wa_contacts_user_id_phone_unique` (`user_id`,`phone`),
  CONSTRAINT `wa_contacts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.wa_contacts: ~4 rows (approximately)
INSERT INTO `wa_contacts` (`id`, `user_id`, `name`, `phone`, `display_phone`, `tags`, `created_at`, `updated_at`) VALUES
	(4, 1, 'pandusolusi.com', '139183079334077@lid', NULL, NULL, '2026-06-25 12:10:13', '2026-06-25 12:47:44'),
	(5, 1, 'NDARI SUKINTA', 'status@broadcast', 'status@broadcast', NULL, '2026-06-25 13:00:19', '2026-06-25 13:00:19'),
	(6, 1, 'Regina', '21401956278498@lid', '21401956278498', NULL, '2026-06-25 19:39:15', '2026-06-25 19:39:15'),
	(7, 1, 'Brodie', '53541699887282@lid', '53541699887282', NULL, '2026-06-25 19:40:55', '2026-06-25 19:40:55');

-- Dumping structure for table wabot.wa_messages
CREATE TABLE IF NOT EXISTS `wa_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `session_id` bigint unsigned DEFAULT NULL,
  `contact_id` bigint unsigned DEFAULT NULL,
  `direction` enum('in','out') COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','sent','delivered','read','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `external_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wa_messages_user_id_foreign` (`user_id`),
  KEY `wa_messages_session_id_foreign` (`session_id`),
  KEY `wa_messages_contact_id_foreign` (`contact_id`),
  CONSTRAINT `wa_messages_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `wa_contacts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `wa_messages_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `wa_sessions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `wa_messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.wa_messages: ~65 rows (approximately)
INSERT INTO `wa_messages` (`id`, `user_id`, `session_id`, `contact_id`, `direction`, `message`, `phone`, `status`, `external_id`, `created_at`, `updated_at`) VALUES
	(1, 1, NULL, NULL, 'in', 'Hi', '82549741211751@lid', 'delivered', 'A5D6C05027E9A07234D5D378DC109937', '2026-06-25 11:48:27', '2026-06-25 11:48:27'),
	(2, 1, NULL, NULL, 'in', 'hi', '82549741211751', 'delivered', 'A5C47B844FADE97D91C365C91000E920', '2026-06-25 12:00:50', '2026-06-25 12:00:50'),
	(3, 1, NULL, NULL, 'out', 'ya ini dia test test', '82549741211751', 'sent', NULL, '2026-06-25 12:00:51', '2026-06-25 12:00:51'),
	(4, 1, NULL, NULL, 'in', 'hi', '82549741211751', 'delivered', 'A577A30EA981C32BA8F483639574074C', '2026-06-25 12:00:59', '2026-06-25 12:00:59'),
	(5, 1, NULL, NULL, 'out', 'ya ini dia test test', '82549741211751', 'sent', NULL, '2026-06-25 12:00:59', '2026-06-25 12:00:59'),
	(8, 1, 5, 4, 'in', 'hi', '139183079334077', 'delivered', 'A52820ECBC458165C812ED384E811A33', '2026-06-25 12:10:13', '2026-06-25 12:10:13'),
	(9, 1, 5, 4, 'out', 'tanya tanya oke deh', '139183079334077', 'sent', NULL, '2026-06-25 12:10:14', '2026-06-25 12:10:14'),
	(10, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CE68BB4B9C77AFF5230E', '2026-06-25 12:10:17', '2026-06-25 12:10:17'),
	(11, 1, 5, 4, 'in', 'hi', '139183079334077', 'delivered', 'A5861554499D428018C18E99747272C1', '2026-06-25 12:10:28', '2026-06-25 12:10:28'),
	(12, 1, 5, 4, 'out', 'tanya tanya oke deh', '139183079334077', 'sent', NULL, '2026-06-25 12:10:29', '2026-06-25 12:10:29'),
	(13, 1, 5, 4, 'in', 'Hi', '139183079334077', 'delivered', 'A5DFF4A399E68FC409F59861C95883D7', '2026-06-25 12:10:31', '2026-06-25 12:10:31'),
	(14, 1, 5, 4, 'out', 'tanya tanya oke deh', '139183079334077', 'sent', NULL, '2026-06-25 12:10:31', '2026-06-25 12:10:31'),
	(15, 1, 5, 4, 'in', 'HI', '139183079334077', 'delivered', 'A5F980F4F415B7F4E54E5ABD2230159C', '2026-06-25 12:10:35', '2026-06-25 12:10:35'),
	(16, 1, 5, 4, 'out', 'tanya tanya oke deh', '139183079334077', 'sent', NULL, '2026-06-25 12:10:35', '2026-06-25 12:10:35'),
	(17, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CE5626849EA88E488FBC', '2026-06-25 12:10:39', '2026-06-25 12:10:39'),
	(18, 1, 5, 4, 'in', 'Hi', '139183079334077', 'delivered', 'A58085186C545BC6EBE4E36B57748ED3', '2026-06-25 12:18:21', '2026-06-25 12:18:21'),
	(19, 1, 5, 4, 'out', 'tanya tanya oke deh', '139183079334077', 'sent', NULL, '2026-06-25 12:18:22', '2026-06-25 12:18:22'),
	(20, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CEA38953AD1584D6AC46', '2026-06-25 12:18:25', '2026-06-25 12:18:25'),
	(21, 1, 5, 4, 'in', 'Ini lindu cipta', '139183079334077', 'delivered', 'A54D2EEE36175ABB50221D203C31ACCC', '2026-06-25 12:18:27', '2026-06-25 12:18:27'),
	(22, 1, 5, 4, 'in', 'Hi', '139183079334077', 'delivered', 'A54F6A7FECE646BAF999311CBBE71132', '2026-06-25 12:19:25', '2026-06-25 12:19:25'),
	(23, 1, 5, 4, 'out', 'tanya tanya oke deh', '139183079334077', 'sent', NULL, '2026-06-25 12:19:25', '2026-06-25 12:19:25'),
	(24, 1, 5, 4, 'in', 'hi', '139183079334077', 'delivered', 'A5BEA82FACE498CCE8FF8BACF4A34A4C', '2026-06-25 12:19:26', '2026-06-25 12:19:26'),
	(25, 1, 5, 4, 'out', 'tanya tanya oke deh', '139183079334077', 'sent', NULL, '2026-06-25 12:19:28', '2026-06-25 12:19:28'),
	(26, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CEC00A038417F4604051', '2026-06-25 12:19:28', '2026-06-25 12:19:28'),
	(27, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CE1659B21CD697C2244E', '2026-06-25 12:21:15', '2026-06-25 12:21:15'),
	(28, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CEF4C6F7C33808DD659B', '2026-06-25 12:23:02', '2026-06-25 12:23:02'),
	(29, 1, 5, 4, 'in', 'hi', '139183079334077', 'delivered', 'A520F5FEE3B5AF429A909E27E61316B2', '2026-06-25 12:23:10', '2026-06-25 12:23:10'),
	(30, 1, 5, 4, 'out', 'silahkan mau tanya apa saja?', '139183079334077', 'sent', NULL, '2026-06-25 12:23:11', '2026-06-25 12:23:11'),
	(31, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CE8A60276431B55DE78A', '2026-06-25 12:23:14', '2026-06-25 12:23:14'),
	(32, 1, 5, 4, 'out', 'test', '139183079334077@lid', 'sent', NULL, '2026-06-25 12:24:21', '2026-06-25 12:24:21'),
	(33, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CE1FCD889C9E9F14513C', '2026-06-25 12:24:24', '2026-06-25 12:24:24'),
	(34, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CE359788F98CE7E3D612', '2026-06-25 12:28:50', '2026-06-25 12:28:50'),
	(35, 1, 5, 4, 'in', 'Hi', '139183079334077', 'delivered', 'A5FF3E0E5C76DB92495819B0B8EAF4DE', '2026-06-25 12:29:00', '2026-06-25 12:29:00'),
	(36, 1, 5, 4, 'out', 'silahkan mau tanya apa saja?', '139183079334077', 'sent', NULL, '2026-06-25 12:29:01', '2026-06-25 12:29:01'),
	(37, 1, 5, 4, 'in', 'hi', '139183079334077', 'delivered', 'A5207E0B22302F5E2F577449FE6D155B', '2026-06-25 12:29:02', '2026-06-25 12:29:02'),
	(38, 1, 5, 4, 'out', 'silahkan mau tanya apa saja?', '139183079334077', 'sent', NULL, '2026-06-25 12:29:03', '2026-06-25 12:29:03'),
	(39, 1, 5, 4, 'in', 'We are sorry, but we have not understand your question. Could you please repeat that?', '139183079334077', 'delivered', 'CE46C03705AAE37C12EE', '2026-06-25 12:29:04', '2026-06-25 12:29:04'),
	(40, 1, 5, 5, 'in', 'Ekuador vs  Jerman', 'status', 'delivered', 'ACE35FA247FC51F66A657AA27FC99E91', '2026-06-25 13:00:19', '2026-06-25 13:00:19'),
	(41, 1, 5, 5, 'in', '2 --- 1', 'status', 'delivered', 'ACF59FAC9B2132E8E8D3C747A01CCCAB', '2026-06-25 19:31:48', '2026-06-25 19:31:48'),
	(42, 1, 5, 5, 'in', 'Turki -- Amerika Serikat', 'status', 'delivered', 'AC5B2028DA070F315D3621B40D18249C', '2026-06-25 19:34:50', '2026-06-25 19:34:50'),
	(43, 1, 5, 6, 'in', 'Mlm bpk ibu\nHarap melunasi Iuran sd bln 6 ya\n\n\nAgam \nPutra,matt, meigan\nGavriel \nMey²,kenzo\nHaidar \nTrifena\nJorrel,jeremy\nAli arkan\nFariz\nJibril\nJason\nUwais \nAlmira', '21401956278498', 'delivered', 'AC86F23F8F70E0C9CCD1A017E0ABC1DD', '2026-06-25 19:39:15', '2026-06-25 19:39:15'),
	(44, 1, 5, 7, 'in', 'ga ada otpnya', '53541699887282', 'delivered', '3A1C335EBF726052DF28', '2026-06-25 19:40:55', '2026-06-25 19:40:55'),
	(45, 1, 5, 7, 'in', 'coba sekali lagi', '53541699887282', 'delivered', '3AE6C4A6C7A40E0AF68F', '2026-06-25 19:40:57', '2026-06-25 19:40:57'),
	(46, 1, 5, 7, 'in', '097138', '53541699887282', 'delivered', '3A520F78272DD340FA65', '2026-06-25 19:42:02', '2026-06-25 19:42:02'),
	(47, 1, 5, 7, 'in', 'oke', '53541699887282', 'delivered', '3AE2AF6FB2EAA7A90BD4', '2026-06-25 19:43:09', '2026-06-25 19:43:09'),
	(48, 1, 5, 7, 'in', 'ubah ppn aja bang', '53541699887282', 'delivered', '3AA0E432552AD2BBC058', '2026-06-25 19:44:57', '2026-06-25 19:44:57'),
	(49, 1, 5, 7, 'in', 'jangan 11 ^', '53541699887282', 'delivered', '3AEFC07414ED63439730', '2026-06-25 19:45:01', '2026-06-25 19:45:01'),
	(50, 1, 5, 7, 'in', '11%', '53541699887282', 'delivered', '3A170A241C99A8CE73A0', '2026-06-25 19:45:07', '2026-06-25 19:45:07'),
	(51, 1, 5, 7, 'in', 'https://bangbrodiebarber.com/admin/blog-categories', '53541699887282', 'delivered', '3A7E2C77BC20B345B750', '2026-06-25 19:51:43', '2026-06-25 19:51:43'),
	(52, 1, 5, 7, 'in', 'SQLSTATE[42S02]: Base table or view not found: 1146 Table \'bang1436_member.blog_categories\' doesn\'t exist (Connection: mysql, Host: 127.0.0.1, Port: 3306, Database: bang1436_member, SQL: select count(*) as `aggregate` from `blog_categories`)', '53541699887282', 'delivered', '3A23721807A74832C824', '2026-06-25 19:52:18', '2026-06-25 19:52:18'),
	(53, 1, 5, 5, 'in', 'ready\nshampo wardah 170ml\nhrg 18 rb', 'status', 'delivered', 'AC0E8951FE8B6430FED179565944D592', '2026-06-25 19:57:00', '2026-06-25 19:57:00'),
	(54, 1, 5, 5, 'in', 'Ready tolak angin isi 12 hrg 45rb saja', 'status', 'delivered', 'ACCFFD46B38DB6AC9FF9098B015BA244', '2026-06-25 19:57:03', '2026-06-25 19:57:03'),
	(55, 1, 5, 5, 'in', 'Ready \nShampo sunsilk  320ml gratis kondisioner \nHrg 32rb saja', 'status', 'delivered', 'AC90B4093F10EF69255273383BD37D57', '2026-06-25 19:57:13', '2026-06-25 19:57:13'),
	(56, 1, 5, 5, 'in', 'Ready Natur e handbody hrg 23rb saja', 'status', 'delivered', 'ACAFF57C80149101E5BB4C6DD4527FCB', '2026-06-25 19:57:27', '2026-06-25 19:57:27'),
	(57, 1, 5, 5, 'in', 'Ready \nShampo sunsilk  320ml gratis kondisioner \nHrg 32rb saja', 'status', 'delivered', 'AC0F71D426D80E8F98DC6CB299312ADA', '2026-06-25 19:57:37', '2026-06-25 19:57:37'),
	(58, 1, 5, 5, 'in', 'Ready\nShampo Lifebuoy 900ml\nJumbo bgt ya\nHrg 50rb saja', 'status', 'delivered', 'ACB42DB3D60239D3A20A41F1599F17F0', '2026-06-25 19:57:44', '2026-06-25 19:57:44'),
	(59, 1, 5, 5, 'in', '1gratis1\nShampo pentine 160ml +conditioner 160ml\nHrg 25rb saja', 'status', 'delivered', 'AC33F27A6B8ED78A18E8D84942D35353', '2026-06-25 19:57:55', '2026-06-25 19:57:55'),
	(60, 1, 5, 7, 'in', 'pajaknya di ilangin aja bang', '53541699887282', 'delivered', '3A95FFDF1E7171585AEA', '2026-06-25 19:58:32', '2026-06-25 19:58:32'),
	(61, 1, 5, 7, 'in', 'soalnya saya kurangin dari pengaturan sistem', '53541699887282', 'delivered', '3AA4ABA49C4F568F9C20', '2026-06-25 19:58:42', '2026-06-25 19:58:42'),
	(62, 1, 5, 7, 'in', 'gabisa', '53541699887282', 'delivered', '3ABE8B28FD38850F0E30', '2026-06-25 19:58:43', '2026-06-25 19:58:43'),
	(63, 1, 5, 7, 'in', 'ttp 11', '53541699887282', 'delivered', '3A89305366A956CBE1E6', '2026-06-25 19:58:50', '2026-06-25 19:58:50'),
	(64, 1, 5, 7, 'in', 'udah di coba', '53541699887282', 'delivered', '3A4447D6B0FE0E22A2FB', '2026-06-25 19:58:52', '2026-06-25 19:58:52'),
	(65, 1, 5, 7, 'in', 'gimna', '53541699887282', 'delivered', '3A5ACFDB8A4EC758EA55', '2026-06-25 20:05:00', '2026-06-25 20:05:00'),
	(66, 1, 5, 7, 'in', 'okee', '53541699887282', 'delivered', '3A092B47421A0DDD699A', '2026-06-25 20:07:10', '2026-06-25 20:07:10'),
	(67, 1, 5, 7, 'in', 'di ilangin gabisa ?', '53541699887282', 'delivered', '3A7DA54943FCAB0547EE', '2026-06-25 20:07:13', '2026-06-25 20:07:13');

-- Dumping structure for table wabot.wa_recurrings
CREATE TABLE IF NOT EXISTS `wa_recurrings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `session_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recurrence` enum('once','daily','weekly','monthly') COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` time DEFAULT NULL,
  `day_of_week` tinyint unsigned DEFAULT NULL,
  `day_of_month` tinyint unsigned DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `media_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` enum('all','group','numbers') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `target_ids` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `last_sent_at` timestamp NULL DEFAULT NULL,
  `next_run_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wa_recurrings_user_id_foreign` (`user_id`),
  KEY `wa_recurrings_session_id_foreign` (`session_id`),
  CONSTRAINT `wa_recurrings_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `wa_sessions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `wa_recurrings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.wa_recurrings: ~0 rows (approximately)

-- Dumping structure for table wabot.wa_servers
CREATE TABLE IF NOT EXISTS `wa_servers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `host` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` int NOT NULL DEFAULT '3100',
  `api_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wa_servers_user_id_foreign` (`user_id`),
  CONSTRAINT `wa_servers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.wa_servers: ~2 rows (approximately)
INSERT INTO `wa_servers` (`id`, `user_id`, `name`, `host`, `port`, `api_key`, `is_active`, `created_at`, `updated_at`) VALUES
	(1, 1, 'vps', '127.0.0.1', 3100, 'wabot-secret-key-change-me', 1, '2026-06-25 10:27:39', '2026-06-25 10:27:39'),
	(2, 1, 'Local Baileys', '127.0.0.1', 3100, 'wabot-secret-key-change-me', 1, '2026-06-25 10:29:20', '2026-06-25 10:29:20');

-- Dumping structure for table wabot.wa_sessions
CREATE TABLE IF NOT EXISTS `wa_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `server_id` bigint unsigned DEFAULT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','qr_ready','connecting','connected','disconnected','error') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `qr_code` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `last_active_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wa_sessions_session_id_unique` (`session_id`),
  KEY `wa_sessions_user_id_foreign` (`user_id`),
  KEY `wa_sessions_server_id_foreign` (`server_id`),
  CONSTRAINT `wa_sessions_server_id_foreign` FOREIGN KEY (`server_id`) REFERENCES `wa_servers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `wa_sessions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.wa_sessions: ~1 rows (approximately)
INSERT INTO `wa_sessions` (`id`, `user_id`, `server_id`, `session_id`, `name`, `phone`, `status`, `qr_code`, `is_active`, `last_active_at`, `created_at`, `updated_at`) VALUES
	(5, 1, 1, 'wa_6a3d7c0a9c5d30.39827655', 'Test2', '6281296052010', 'connected', '2@31Be600Ra1yJCFaywuSCgwXUjaRFSlHQ/JjAcR0g/eszlOyvnJq/6USlutTPYP2ji/KTYgOs1dhGvrOdW5RY4dym/gFUvh5REgI=,7IxWs75CVsLgZ1gO9080ywlZcwx1QnJvS02qcYQwvFM=,vfcjCmLTCF+sLvb/cUYsMTv+hOARsB5VtlsEvQ1YumU=,pwBozx+KhCTWBolnErbfPyWKNvSqxrwOygaSMt1IyJU=', 1, '2026-06-25 19:47:54', '2026-06-25 12:05:46', '2026-06-25 19:47:54');

-- Dumping structure for table wabot.wa_session_logs
CREATE TABLE IF NOT EXISTS `wa_session_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `session_id` bigint unsigned NOT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `logged_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wa_session_logs_user_id_foreign` (`user_id`),
  KEY `wa_session_logs_session_id_foreign` (`session_id`),
  CONSTRAINT `wa_session_logs_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `wa_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wa_session_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table wabot.wa_session_logs: ~2 rows (approximately)
INSERT INTO `wa_session_logs` (`id`, `user_id`, `session_id`, `event`, `phone`, `reason`, `logged_at`, `created_at`, `updated_at`) VALUES
	(1, 1, 5, 'connected', '6281296052010:46@s.whatsapp.net', NULL, '2026-06-25 19:31:14', '2026-06-25 19:31:14', '2026-06-25 19:31:14'),
	(2, 1, 5, 'connected', '6281296052010:46@s.whatsapp.net', NULL, '2026-06-25 19:47:54', '2026-06-25 19:47:54', '2026-06-25 19:47:54');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
